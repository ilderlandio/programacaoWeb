<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Criação de diretórios e upload de arquivos </title>
</head>
<body>
	<h2>Sistema de Upload de Arquivos </h2>
   <form enctype="multipart/form-data" method="post" action="upload.php">
   	<p> Nome do diretório:
   	 <input type="text" name="diretorio"> 
   	</p>

   	<p>Digite seu nome: <input type="text" name="nome"></p>

   	<p> <input name="userfile" type="file" /> </p>
   	<p> <button type="submit"> Enviar arquivo </button> </p>
   </form>
</body>
</html>