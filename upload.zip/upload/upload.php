<?php
var_dump($_FILES['userfile']);

echo  $_FILES['userfile']['name'];

$size =  $_FILES['userfile']['size']; 

$erro =  $_FILES['userfile']['error']; 

echo "<br>".$size; 
echo "<br>".$erro; 

$dir = $_POST['diretorio']; 

if(is_dir($dir)){
	// nada 
}else{
	mkdir($dir); 
}

$nomeTemp = $_FILES['userfile']['tmp_name']; 
$nomeF = $_FILES['userfile']['name'];
$nomeFile = $_POST['nome']; 

$parInfo = pathinfo("$nomeF");

$ext = $parInfo['extension'];  

$ctr = move_uploaded_file($nomeTemp,$dir."/".$nomeFile.".$ext");

if($ctr){
	echo "Upload realizado!";
}else {
	echo "Upload não realizado!"; 
}