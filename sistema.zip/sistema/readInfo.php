<?php
// receber via GET o id(nome) do arquivo que deve ser lido

$id = $_GET['id'];

// fazer leitura do arquivo e imprimir as informações.

$dados = file("cadastros/$id");

// var_dump($dados);

$size = count($dados);  // pega o tamanho do vetor

for($i=0; $i < $size; $i++) { 
	echo $dados[$i]."<br>"; 
}


  