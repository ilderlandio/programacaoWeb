<?php
// Validar o formulário
extract($_POST); 

$dados = $nome."\r\n".$cargo."\r\n".$salario."\r\n".$dependentes."\r\n";

// gravar as informaçoes validadas no arquivo
$refFile = fopen("cadastros/$id.txt","a+");

fwrite($refFile,$dados);

fclose($refFile); 

// Usar os scandir(ver documentação) para listar os nomes de arquivos criados. 
$file = scandir("cadastros");

$size = count($file);
// var_dump($file);

for($i=0; $i < $size; $i++) { 
	if($file[$i] != '.' && $file[$i] != '..'){
	 echo "<a href=readinfo.php?id=$file[$i]> $file[$i] </a><br>"; 
	}
} 


// // Criar automaticanete links que possam levar ao arquivo 
// // readInfo.php, de modo que cada links passe via GET o nome do arquivo a ser lido. 

?> 