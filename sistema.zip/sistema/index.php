<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
 <h2>Cadastrar funcionário</h2>
 <form method="post" action="cad.php">
 	<p> id: <input type="number" name="id"> </p>
 	<p> Nome: <input type="text" name="nome"> </p>
 	<p> Cargo: <input type="text" name="cargo"> </p>
 	<p> Salário: <input type="text" name="salario"> </p>
 	<p> Qtd Dependentes: <input type="number" name="dependentes"> </p>
 	<button type="submit"> Cadastrar </button>
 </form>
 
</body>
</html>