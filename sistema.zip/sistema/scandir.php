<?php

$file = scandir("cadastros");

$size = count($file);

for($i=0; $i < $size; $i++) { 
	if($file[$i] != '.' && $file[$i] != '..'){
	 echo $file[$i]."<br>"; 
	}
} 

